<!DOCTYPE html>
<html>
<head>
    <meta charset=utf8>
    <title>Inclusão de novos usuários</title>
</head>
<body>
<form action=salvar.php>
<p>Nome</p>
<input type=text name=nome1>
<p>Data de nascimento</p>
<input type=date name=datadenascimento1>
<p>Salario</p>
<input type="text" name="salario1" value="$" >
<br><br>
<input type=submit value=Salvar>
</form> 
<br><br>
<a href=index.php>Voltar</a>   
</body>
</html>